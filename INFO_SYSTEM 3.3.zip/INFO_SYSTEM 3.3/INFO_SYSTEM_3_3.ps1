# ============================================================
#  COLETA DE INFORMACOES DO SISTEMA
#  Criado por Analista Renata Scheiner
# ============================================================

$Host.UI.RawUI.WindowTitle = "Shark Devs | Coleta de Informacoes do Sistema"

# ── Desktop correto mesmo rodando como Administrador ────────
$OriginalUser = (Get-CimInstance Win32_Process -Filter "ProcessId=$PID").GetRelated('Win32_LogonSession') |
                ForEach-Object { (Get-CimInstance -Query "ASSOCIATORS OF {Win32_LogonSession.LogonId=$($_.LogonId)} WHERE AssocClass=Win32_LoggedOnUser").Name } |
                Select-Object -First 1

if (-not $OriginalUser) { $OriginalUser = $env:USERNAME }

$DesktopPath = "C:\Users\$OriginalUser\Desktop"

if (-not (Test-Path $DesktopPath)) {
    $DesktopPath = [Environment]::GetFolderPath("Desktop")
}

# ── Escolha do formato de saida ──────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host "  |   TEAM INFRA  -  Controle de Identidade             |" -ForegroundColor Cyan
Write-Host "  |        Coleta de Informacoes do Sistema              |" -ForegroundColor Cyan
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host ""
Write-Host "   Maquina  : $env:COMPUTERNAME"
Write-Host "   Usuario  : $OriginalUser"
Write-Host "   Data     : $(Get-Date -Format 'dd/MM/yyyy   Hora: HH:mm:ss')"
Write-Host ""
Write-Host "  ------------------------------------------------------"
Write-Host "   Escolha o formato do relatorio:"
Write-Host ""
Write-Host "   [1]  TXT  (arquivo de texto simples)"
Write-Host "   [2]  PDF  (via Microsoft Print to PDF)"
Write-Host ""

do {
    $FormatoEscolha = Read-Host "   Digite 1 ou 2 e pressione ENTER"
} while ($FormatoEscolha -notin @("1","2"))

$GerarPDF = ($FormatoEscolha -eq "2")

$TxtOutput = "$DesktopPath\info_sistema_$env:COMPUTERNAME.txt"
$PdfOutput = "$DesktopPath\info_sistema_$env:COMPUTERNAME.pdf"

Clear-Host
Write-Host ""
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host "  |   TEAM INFRA  -  Controle de Identidade             |" -ForegroundColor Cyan
Write-Host "  |        Coleta de Informacoes do Sistema              |" -ForegroundColor Cyan
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host ""
Write-Host "   Maquina  : $env:COMPUTERNAME"
Write-Host "   Usuario  : $OriginalUser"
Write-Host "   Data     : $(Get-Date -Format 'dd/MM/yyyy   Hora: HH:mm:ss')"
Write-Host ""
Write-Host "  ------------------------------------------------------"
Write-Host "   Por favor, aguarde. NAO feche esta janela!"
Write-Host "  ------------------------------------------------------"
Write-Host ""

# ── Cabecalho do arquivo TXT ─────────────────────────────────
@"
============================================================
       OUTPUT DE INFORMACOES DO SISTEMA
============================================================
Data/Hora : $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')
Maquina   : $env:COMPUTERNAME
Usuario   : $OriginalUser

"@ | Out-File -FilePath $TxtOutput -Encoding UTF8

# ── Funcao auxiliar ──────────────────────────────────────────
function Write-Section {
    param($Title, $Content)
    @"
[$Title]
$Content

"@ | Out-File -FilePath $TxtOutput -Encoding UTF8 -Append
}

# [1] Usuario
Write-Host "   [ 1 / 12 ]  Usuario logado..." -NoNewline
Write-Section "Usuario Logado" (whoami)
Write-Host "   OK!" -ForegroundColor Green

# [2] Hostname
Write-Host "   [ 2 / 12 ]  Hostname..." -NoNewline
Write-Section "Hostname" (hostname)
Write-Host "   OK!" -ForegroundColor Green

# [3] IP
Write-Host "   [ 3 / 12 ]  Endereco IP..." -NoNewline
$IPs = (Get-NetIPAddress | Where-Object { $_.AddressFamily -eq 'IPv4' -and $_.PrefixOrigin -ne 'WellKnown' }).IPAddress
Write-Section "Endereco IP" ($IPs -join "`n")
Write-Host "   OK!" -ForegroundColor Green

# [4] Rede
Write-Host "   [ 4 / 12 ]  Adaptadores..." -NoNewline
$Adapters = Get-NetAdapter | Select Name, MacAddress | Format-Table | Out-String
Write-Section "Adaptadores de Rede" $Adapters.Trim()
Write-Host "   OK!" -ForegroundColor Green

# [5] SO
Write-Host "   [ 5 / 12 ]  Sistema..." -NoNewline
$OS = (Get-CimInstance Win32_OperatingSystem).Caption
Write-Section "Sistema Operacional" $OS
Write-Host "   OK!" -ForegroundColor Green

# [6] BIOS
Write-Host "   [ 6 / 12 ]  BIOS..." -NoNewline
$BIOS = (Get-CimInstance Win32_BIOS).SerialNumber
Write-Section "BIOS Serial" $BIOS
Write-Host "   OK!" -ForegroundColor Green

# [7] CPU
Write-Host "   [ 7 / 12 ]  CPU..." -NoNewline
Write-Section "Processador" (Get-CimInstance Win32_Processor).Name
Write-Host "   OK!" -ForegroundColor Green

# [8] RAM
Write-Host "   [ 8 / 12 ]  RAM..." -NoNewline
$RAM = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB,2)
Write-Section "Memoria RAM" "$RAM GB"
Write-Host "   OK!" -ForegroundColor Green

# [9] Disco
Write-Host "   [ 9 / 12 ]  Disco..." -NoNewline
$Disks = Get-PhysicalDisk | ForEach { [math]::Round($_.Size / 1GB,2) }
Write-Section "Disco (GB)" ($Disks -join "`n")
Write-Host "   OK!" -ForegroundColor Green

# [10] Defender
Write-Host "   [ 10 / 12 ] Defender..." -NoNewline
$Def = Get-MpComputerStatus | Select AntivirusEnabled,RealTimeProtectionEnabled | Out-String
Write-Section "Windows Defender" $Def.Trim()
Write-Host "   OK!" -ForegroundColor Green

# [11] Licenca
Write-Host "   [ 11 / 12 ] Licenca..." -NoNewline
$Key = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform').BackupProductKeyDefault
Write-Section "Licenca Windows" $Key
Write-Host "   OK!" -ForegroundColor Green

# [12] BitLocker
Write-Host "   [ 12 / 12 ] BitLocker..." -NoNewline

$RecoveryInfo = @()

Get-BitLockerVolume | ForEach-Object {
    $Drive = $_.MountPoint
    foreach ($kp in $_.KeyProtector) {
        if ($kp.KeyProtectorType -eq "RecoveryPassword") {
            $RecoveryInfo += "Unidade       : $Drive"
            $RecoveryInfo += "Identificador : $($kp.KeyProtectorId)"
            $RecoveryInfo += "Chave         : $($kp.RecoveryPassword)"
            $RecoveryInfo += ""
        }
    }
}

if ($RecoveryInfo.Count -eq 0) {
    $RecoveryInfo = @("Nao encontrado ou desativado")
}

Write-Section "BitLocker - Recovery Key" ($RecoveryInfo -join "`n")
Write-Host "   OK!" -ForegroundColor Green

# ── Geracao do PDF ───────────────────────────────────────────
if ($GerarPDF) {
    Write-Host ""
    Write-Host "   Gerando PDF..." -NoNewline

    $PrinterName = "Microsoft Print to PDF"
    $PrinterExists = Get-Printer -Name $PrinterName -ErrorAction SilentlyContinue

    if ($PrinterExists) {
        try {
            Add-Type -AssemblyName System.Drawing

            $content = Get-Content $TxtOutput -Raw
            $lines   = $content -split "`r?`n"

            $pd = New-Object System.Drawing.Printing.PrintDocument
            $pd.PrinterSettings.PrinterName  = $PrinterName
            $pd.PrinterSettings.PrintToFile  = $true
            $pd.PrinterSettings.PrintFileName = $PdfOutput

            # Margens em centesimos de polegada (100 = 1 polegada)
            $pd.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(60, 60, 60, 60)

            $script:lineIndex = 0

            $pd.add_PrintPage({
                param($sender, $ev)

                $font   = New-Object System.Drawing.Font("Courier New", 9)
                $brush  = [System.Drawing.Brushes]::Black
                $x      = [float]$ev.MarginBounds.Left
                $y      = [float]$ev.MarginBounds.Top
                $bottom = [float]$ev.MarginBounds.Bottom
                $lh     = $font.GetHeight($ev.Graphics)

                while ($script:lineIndex -lt $lines.Count) {
                    if (($y + $lh) -gt $bottom) {
                        $ev.HasMorePages = $true
                        return
                    }
                    $ev.Graphics.DrawString($lines[$script:lineIndex], $font, $brush, $x, $y)
                    $y += $lh
                    $script:lineIndex++
                }

                $ev.HasMorePages = $false
                $font.Dispose()
            })

            $pd.Print()
            $pd.Dispose()

            # Aguarda o driver finalizar a escrita do arquivo
            $timeout = 30
            $elapsed = 0
            while (-not (Test-Path $PdfOutput) -and $elapsed -lt $timeout) {
                Start-Sleep -Milliseconds 500
                $elapsed += 0.5
            }

            if (Test-Path $PdfOutput) {
                Write-Host "   OK!" -ForegroundColor Green
            } else {
                throw "Arquivo PDF nao foi criado pelo driver."
            }

        } catch {
            Write-Host ""
            Write-Host "   Falha ao gerar PDF: $_" -ForegroundColor Yellow
            Write-Host "   Relatorio salvo como TXT." -ForegroundColor Yellow
            $GerarPDF = $false
        }

    } else {
        Write-Host ""
        Write-Host "   Impressora 'Microsoft Print to PDF' nao encontrada." -ForegroundColor Yellow
        Write-Host "   Relatorio salvo como TXT." -ForegroundColor Yellow
        $GerarPDF = $false
    }

    # Remove o TXT intermediario se PDF foi gerado com sucesso
    if ($GerarPDF -and (Test-Path $PdfOutput)) {
        Remove-Item $TxtOutput -ErrorAction SilentlyContinue
    }
}

# ── Tela final ───────────────────────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host "  |        COLETA CONCLUIDA!                             |" -ForegroundColor Cyan
Write-Host "  +======================================================+" -ForegroundColor Cyan
Write-Host ""
Write-Host "   Relatorio salvo em:"

if ($GerarPDF -and (Test-Path $PdfOutput)) {
    Write-Host "   $PdfOutput" -ForegroundColor Yellow
} else {
    Write-Host "   $TxtOutput" -ForegroundColor Yellow
}

Write-Host ""
Read-Host "Pressione ENTER para fechar"
exit
